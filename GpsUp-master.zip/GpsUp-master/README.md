# GpsUp

https://play.google.com/store/apps/details?id=kupchinskii.ruslan.gpsup

This is a simple application for GPS fixing, testing GPS, auto-update A-GPS data, GPS Quick Start, see the current coordinates, speed, precision positioning and information on the level of each detected satellite signal.

Can be used in conjunction with the navigation software or games requiring geolocation. In the presence of the Internet much faster it detects the GPS signal and increases the accuracy of the signal.
