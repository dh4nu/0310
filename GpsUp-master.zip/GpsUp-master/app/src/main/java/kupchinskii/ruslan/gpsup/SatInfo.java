package kupchinskii.ruslan.gpsup;


public class SatInfo {

    public boolean isFix;
    public int num;
    public float snr;
}
