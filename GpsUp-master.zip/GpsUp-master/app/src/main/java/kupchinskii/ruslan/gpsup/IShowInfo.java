package kupchinskii.ruslan.gpsup;


public interface IShowInfo {
    void ShowInfo(String info);

}
