package kupchinskii.ruslan.gpsup;


public interface IGpsResult {
    GPS_Result getGpsResult();

}
