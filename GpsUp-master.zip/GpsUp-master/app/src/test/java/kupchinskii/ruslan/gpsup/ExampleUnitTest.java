package kupchinskii.ruslan.gpsup;

public class ExampleUnitTest {

}